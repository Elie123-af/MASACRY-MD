<div id="header" align="center">
  <img src="https://64.media.tumblr.com/d1acaa13b34b58735fc91a379303cff8/tumblr_pun53hNdAw1t2ijmjo1_540.gif" height="200"/> <br> <br>
  <img src="https://komarev.com/ghpvc/?username=your-github-FaouzKK&style=flat-square&color=blue" alt=""/>
</div>
<h1>
  hey there
  <img src="https://media.giphy.com/media/hvRJCLFzcasrR4ia7z/giphy.gif" width="30px"/>
</h1>


<div align="center">
   <img src="https://media.giphy.com/media/dWesBcTLavkZuG35MI/giphy.gif" width="600" height="300"/>
</div>

---

### :woman_technologist: A propos de moi :

Je suis ou plutot je m'entraine a devenir un devellopeur fullStack du Togo <img src="https://media.giphy.com/media/WUlplcMpOCEmTGBtBW/giphy.gif" width="30"> .

-🔭 Je suis un étudiant passionné par l'informatique, spécialisé dans le développement d'applications. Toujours curieux d'apprendre de nouvelles technologies et de relever des défis, je suis motivé à contribuer à des projets innovants et à développer mes compétences dans le domaine de la programmation.

-🌱   Je travail de temps a autre sur des project educatif comme des application ou jeu webs , des plugins de jeu video ou des bots sur Node.js

-📱 Me contacter : 22891733300 . Je suis disponible pour toutes collaboration

---

### :hammer_and_wrench: Mes principaux Languages de programmation :

<div align = center>
  <img src="https://github.com/devicons/devicon/blob/master/icons/css3/css3-plain-wordmark.svg"  title="CSS3" alt="CSS" width="40" height="40"/>&nbsp;
  <img src="https://github.com/devicons/devicon/blob/master/icons/html5/html5-original.svg" title="HTML5" alt="HTML" width="40" height="40"/>&nbsp;
  <img src="https://github.com/devicons/devicon/blob/master/icons/javascript/javascript-original.svg" title="JavaScript" alt="JavaScript" width="40" height="40"/>&nbsp;
  <img src="https://github.com/devicons/devicon/blob/master/icons/mysql/mysql-original-wordmark.svg" title="MySQL"  alt="MySQL" width="40" height="40"/>&nbsp;
  <img src="https://github.com/devicons/devicon/blob/master/icons/nodejs/nodejs-original-wordmark.svg" title="NodeJS" alt="NodeJS" width="40" height="40"/>&nbsp;
  <img src="https://github.com/devicons/devicon/blob/master/icons/postgresql/postgresql-original.svg" title="Postgresal" alt="Postgresql" width="40" height="40"/>&nbsp;
  <img src="https://github.com/devicons/devicon/blob/master/icons/php/php-original.svg" title="Php" alt="Php" width="40" height="40"/>&nbsp;
</div>

---

### :fire: Mes Stats :

[![GitHub Streak](https://streak-stats.demolab.com/?user=FaouzKK&theme=dark)](https://git.io/streak-stats)

[![Top Langs](https://github-readme-stats.vercel.app/api/top-langs/?username=FaouzKK&layout=compact&theme=vision-friendly-dark)](https://github.com/anuraghazra/github-readme-stats)
